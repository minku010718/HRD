package com.example.debug;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);

        int a = 2;
        int b = 3;
        int c = 5;
        int result = 0;
        result = a << 2;                // 8
        result += b;                    // 11
        result = (result + c) >> 1;     // 8

        result = add(result, 3);     // 11
        textView.setText(String.valueOf(result));
    }

    int add(int a, int b) {
        int sum;
        sum = a + b;
        return sum;
    }
}