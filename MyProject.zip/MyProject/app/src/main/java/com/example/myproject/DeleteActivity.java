package com.example.myproject;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DeleteActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText editDeleteId;
    private Button btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_delete);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);
        editDeleteId = findViewById(R.id.delete_id);
        btnDelete = findViewById(R.id.delete);

        btnDelete.setOnClickListener(v -> {
            String id = editDeleteId.getText().toString().trim();

            if (id.isEmpty()) {
                Toast.makeText(this, "학번을 입력해주세요.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!dbHelper.checkStudentExists(id)) {
                Toast.makeText(this, "해당 학번의 학생이 없습니다.", Toast.LENGTH_SHORT).show();
            } else {
                // 삭제 전 확인 다이얼로그 표시
                showDeleteConfirmationDialog(id);
            }
        });
    }

    private void showDeleteConfirmationDialog(String id) {
        new AlertDialog.Builder(this).setTitle("삭제 확인").setMessage("정말 " + id + "학번의 정보를 삭제하시겠습니까?")
                .setPositiveButton("삭제", (dialog, which) -> {
                    dbHelper.deleteStudent(id);
                    Toast.makeText(this, "삭제되었습니다.", Toast.LENGTH_SHORT).show();
                    finish(); // 삭제 후 액티비티 종료
                }).setNegativeButton("취소", null).setIcon(android.R.drawable.ic_dialog_alert).show();
    }
}