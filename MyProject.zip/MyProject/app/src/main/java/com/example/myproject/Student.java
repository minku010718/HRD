package com.example.myproject;

import androidx.annotation.NonNull;

public class Student {
    private String id; // 학번
    private String name; // 이름
    private String phone; // 전화번호
    private String department; // 학과
    private String gpa; // 평점

    public Student(String id, String name, String phone, String department, String gpa) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.department = department;
        this.gpa = gpa;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getGpa() {
        return gpa;
    }

    public void setGpa(String gpa) {
        this.gpa = gpa;
    }

    @NonNull
    @Override
    public String toString() {
        return "학번: " + id + '\n' + "이름: " + name + '\n' + "전화번호: " + phone + '\n' +
                "학과: " + department + '\n' + "평점: " + gpa;
    }
}
