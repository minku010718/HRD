package com.example.myproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisterActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText editId, editName, editPhone, editDepartment, editGpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);
        editId = findViewById(R.id.edit_id);
        editName = findViewById(R.id.edit_name);
        editPhone = findViewById(R.id.edit_phone);
        editDepartment = findViewById(R.id.edit_department);
        editGpa = findViewById(R.id.edit_gpa);

        Button btnSave = findViewById(R.id.save);

        btnSave.setOnClickListener(v -> {
            String id = editId.getText().toString().trim();
            String name = editName.getText().toString().trim();
            String phone = editPhone.getText().toString().trim();
            String department = editDepartment.getText().toString().trim();
            String gpa = editGpa.getText().toString().trim();

            if (id.isEmpty()) {
                Toast.makeText(this, "학번을 입력하세요.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.checkStudentExists(id)) {
                Toast.makeText(this, "이미 존재하는 학번입니다.", Toast.LENGTH_SHORT).show();
            } else {
                Student student = new Student(id, name, phone, department, gpa);
                dbHelper.addStudent(student);
                Toast.makeText(this, "저장했습니다.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}