package com.example.myproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DBActivity extends AppCompatActivity {

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dbactivity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        Button btnRegister = findViewById(R.id.register);
        Button btnUpdate = findViewById(R.id.update);
        Button btnDelete = findViewById(R.id.delete);
        Button btnView = findViewById(R.id.view);

        btnRegister.setOnClickListener(v -> {
            startActivity(new Intent(DBActivity.this, RegisterActivity.class));
        });

        btnUpdate.setOnClickListener(v -> {
            startActivity(new Intent(DBActivity.this, UpdateActivity.class));
        });

        btnDelete.setOnClickListener(v -> {
            startActivity(new Intent(DBActivity.this, DeleteActivity.class));
        });

        btnView.setOnClickListener(v -> {
            startActivity(new Intent(DBActivity.this, ViewActivity.class));
        });

    }

}