package com.example.myproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UpdateActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText editName, editPhone, editDepartment, editGpa;
    private TextView textId;
    private Button btnUpdate;
    private LinearLayout updateLayout;
    private Student studentToUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        updateLayout = findViewById(R.id.update_form_layout);
        textId = findViewById(R.id.update_id);
        editName = findViewById(R.id.update_name);
        editPhone = findViewById(R.id.update_phone);
        editDepartment = findViewById(R.id.update_department);
        editGpa = findViewById(R.id.update_gpa);
        btnUpdate = findViewById(R.id.update);

        showFindStudentDialog();

        btnUpdate.setOnClickListener(v -> {
            if (studentToUpdate != null) {
                studentToUpdate.setName(editName.getText().toString().trim());
                studentToUpdate.setPhone(editPhone.getText().toString().trim());
                studentToUpdate.setDepartment(editDepartment.getText().toString().trim());
                studentToUpdate.setGpa(editGpa.getText().toString().trim());

                dbHelper.updateStudent(studentToUpdate);
                Toast.makeText(this, "수정 완료.", Toast.LENGTH_SHORT).show();
                finish(); // 수정 완료 후 액티비티 종료
            }
        });
    }

    private void showFindStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("수정할 학생의 학번 입력");

        final EditText input = new EditText(this);
        input.setHint("학번");
        builder.setView(input);

        builder.setPositiveButton("확인", (dialog, which) -> {
            String id = input.getText().toString().trim();
            if (id.isEmpty()) {
                Toast.makeText(this, "학번을 입력하세요.", Toast.LENGTH_SHORT).show();
                finish(); // 학번 미입력 시 액티비티 종료
                return;
            }

            studentToUpdate = dbHelper.getStudent(id);

            if (studentToUpdate == null) {
                Toast.makeText(this, "해당 학번의 학생이 없습니다.", Toast.LENGTH_SHORT).show();
                finish(); // 학생이 없으면 액티비티 종료
            } else {
                // 학생 정보를 찾았으면 수정 폼을 보여주고 데이터 채우기
                updateLayout.setVisibility(View.VISIBLE);
                populateUI(studentToUpdate);
            }
        });

        builder.setNegativeButton("취소", (dialog, which) -> {
            dialog.cancel();
            finish(); // 취소 시 액티비티 종료
        });

        builder.setCancelable(false); // 바깥쪽 터치로 닫기 비활성화
        builder.show();
    }

    private void populateUI(Student student) {
        textId.setText("학번: " + student.getId());
        editName.setText(student.getName());
        editPhone.setText(student.getPhone());
        editDepartment.setText(student.getDepartment());
        editGpa.setText(student.getGpa());
    }
}