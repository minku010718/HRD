package com.example.memo;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MemoActivity extends AppCompatActivity {
    private EditText memoEditText;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable saveRunnable;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        memoEditText = findViewById(R.id.editText);

        memoEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (saveRunnable != null) {
                    handler.removeCallbacks(saveRunnable);
                }
                saveRunnable = new Runnable() {
                    @Override
                    public void run() {

                    }
                };
                handler.postDelayed(saveRunnable, 1500L);
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        String currentText = memoEditText.getText().toString();
    }
}
